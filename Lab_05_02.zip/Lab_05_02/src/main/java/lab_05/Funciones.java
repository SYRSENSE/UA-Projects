
package lab_05;
import java.util.Scanner;
public class Funciones {
   public void Menu(){
       boolean flag = true;
       do{
        System.out.println("==Menu==");
        System.out.println("[1]Contar dígitos");
        System.out.println("[2]Sumar dígitos");
        System.out.println("[3]Maximo comun divisor (MCD)");
        System.out.println("[4]Invertir una cadena");
        System.out.println("[5]Salir");  
        int op = validarOpcion();
        switch (op){
            case 1:
                System.out.println("La cantidad de digitos de su numero es de:"+ validar_contar_digito());
                break;
            case 2:
                System.out.println("La Suma de digitos de su numero es de:" + validar_sumar_digitos());
                break;
            case 3:
                System.out.println("El mcd de sus 2 numeros es:" + validar_obtener_mcd());
                break;
            case 4:
                System.out.println("Su cadena invertida es:" + validar_invertir_cadena());
                break;
            case 5:
                System.out.println("Adios :)");
                flag = false;
                break;
            default:
                System.out.println("How :(");
        }
       }while(flag);
   }
   public int validarOpcion(){
       Scanner scan = new Scanner(System.in);
       System.out.println("Ingrese una opcion: ");
       try{
           int op = Integer.parseInt(scan.next());
           return op;
       }catch(NumberFormatException e){
           System.out.println("Error: Solo pueden ser numeros");
       }
       return 0;
    }
   public int contar_digitos(String digito, int i){
       if (i == digito.length()){
           return i;
       }else
           return contar_digitos(digito, i+1);
       
   }
   public int validar_contar_digito(){
       Scanner scan = new Scanner(System.in);
       System.out.println("Ingrese su numero: ");
       try{
           int op = Integer.parseInt(scan.next());
           return contar_digitos(Integer.toString(op),0);
       }catch(NumberFormatException e){
           System.out.println("Error: Solo pueden ser numeros");
       }
       return 0;
   } 
   public int validar_sumar_digitos(){
       Scanner scan = new Scanner(System.in);
       System.out.println("Ingrese su numero: ");
       try{
           int op = Integer.parseInt(scan.next());
           return sumar_digitos(op);
       }catch(NumberFormatException e){
           System.out.println("Error: Solo pueden ser numeros");
       }
       return 0;
   }
   public int sumar_digitos(int num){
        if(num==0){
            return 0;
        } else 
            return sumar_digitos(num/10) + num%10;
    }
   public int obtener_mcd(int num1, int num2) {
       if(num2==0)
           return num1;
       else
           return obtener_mcd(num2, num1 % num2);
   }
   public int validar_obtener_mcd(){
       Scanner scan = new Scanner(System.in);
       System.out.println("Ingrese sus 2 numeros: ");
       try{
           int num1 = Integer.parseInt(scan.next());
           int num2 = Integer.parseInt(scan.next());
           return obtener_mcd(num1,num2);
       }catch(NumberFormatException e){
           System.out.println("Error: Solo pueden ser numeros");
       }
       return 0;
   }
   public String invertir_cadena(String cadena){
       if (cadena.length() == 0){
           return cadena;   
       }else
           return invertir_cadena(cadena.substring(1)) + cadena.charAt(0);
   }
   public String validar_invertir_cadena(){
      Scanner scan = new Scanner(System.in);
       System.out.println("Ingrese su cadena a invertir: ");
       String cadena = scan.nextLine();
       return invertir_cadena(cadena);
   }
}   

