

package lab_05;

public class Lab_05 {

    public static void main(String[] args) {
       Funciones func = new Funciones();
       func.Menu();
    }
}
